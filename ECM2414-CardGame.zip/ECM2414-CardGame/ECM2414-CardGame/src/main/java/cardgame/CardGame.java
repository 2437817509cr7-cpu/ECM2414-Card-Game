package cardgame;

public class CardGame {
    public static void main(String[] args) {
        System.out.println("CardGame started.");
    }
}
